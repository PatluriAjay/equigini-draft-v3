import InvestorLayout from "@/components/investor/InvestorLayout";

export default function InvestorRootLayout({ children }) {
  return <InvestorLayout>{children}</InvestorLayout>;
}
