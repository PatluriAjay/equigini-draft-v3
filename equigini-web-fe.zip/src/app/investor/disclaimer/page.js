export default function Disclaimer() {
  return (
     <div className="pb-6">
      <h1 className="heading-main">Work in Progress</h1>
      <p className="p-medium">This page is currently under development.</p>
    </div>
  );
}
