export default function AnalystDashboardPage() {
  return (
    <div className="">
      <h1 className="heading-main">Welcome Analyst!</h1>
      <p className="p-large">Dashboard content will be displayed here.</p>
    </div>
  );
}
