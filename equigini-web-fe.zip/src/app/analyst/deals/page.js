export default function AnalystDealsPage() {
  return (
    <div className="">
      <h1 className="heading-main">Work in Progress</h1>
      <p className="p-medium">This page is currently under development.</p>
    </div>
  );
} 