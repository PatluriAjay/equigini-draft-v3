import AnalystLayout from "@/components/analyst/AnalystLayout";

export default function AnalystRootLayout({ children }) {
  return <AnalystLayout>{children}</AnalystLayout>;
}
