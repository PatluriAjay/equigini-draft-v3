import DealListPage from "@/components/admin/investor-view/DealListPage";

export default function DealsPage() {
  return <DealListPage />;
}
