import NDAReviewPanel from "@/components/admin/nda/NDAReviewPanel";

export default function NDAPage() {
  return (
    <div className="">
      <NDAReviewPanel />
    </div>
  );
}
