// Simple placeholder for each admin page
export default function AdminDashboardPage() {
  return (
    <div className="">
      <h1 className="heading-main">Welcome Admin!</h1>
      <p className="p-large">Dashboard content will be displayed here.</p>
    </div>
  );
}
