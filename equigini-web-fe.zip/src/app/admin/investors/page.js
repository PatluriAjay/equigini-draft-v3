'use client'  
import InvestorListPage from "@/components/admin/investor-view/InvestorListPage";

export default function InvestorsPage() {
  return <InvestorListPage />;
}
