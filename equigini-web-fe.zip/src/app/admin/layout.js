import AdminLayout from "@/components/admin/AdminLayout";

export default function AdminRootLayout({ children }) {
  return <AdminLayout>{children}</AdminLayout>;
}
