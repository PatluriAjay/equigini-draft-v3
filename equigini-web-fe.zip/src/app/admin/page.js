import { redirect } from "next/navigation";

export default function AdminIndexPage() {
  redirect("/admin/dashboard");
  return null;
}
