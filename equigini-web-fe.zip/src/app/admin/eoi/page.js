import EOIReviewPanel from "@/components/admin/eoi/EOIReviewPanel";

export default function EOIPage() {
  return (
  <div className="">
    <EOIReviewPanel />
  </div>
  );
}
