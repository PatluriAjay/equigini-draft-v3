"use client";
import BlogListPage from "@/components/admin/blogs/BlogListPage";

export default function BlogsPage() {
  return <BlogListPage />;
}
