import InvestorApproval from '../../../components/admin/InvestorApproval';

export default function InvestorApprovalPage() {
  return <InvestorApproval />;
}
